import java.util.*;
public class Subnet 
{
   
	public static void main(String[] args)
	{
	   Scanner sc=new Scanner(System.in);
	   System.out.print("Enter IP address:");
	   String ip=sc.nextLine();
	   String split_ip[]=ip.split("\\.");
	   String []split_bip=new String[4];
	   String bip="";
	   for (int i = 0; i < 4; i++) 
	   {
		    split_bip[i]=appendZero(Integer.toBinaryString(Integer.parseInt(split_ip[i])));
		    bip+=split_bip[i]+".";
	    }
	   System.out.println("\n IP in binary is "+bip);
	   System.out.print("\n Enter the number of sub-networks: ");
		int n = sc.nextInt();
		n=(int)Math.ceil(Math.log(n)/Math.log(2));
		System.out.println("\n Number of bits required for sub-network addressing = "+n);
		String checkclass=ip.substring(0,3);
		int cc=Integer.parseInt(checkclass);
		if(cc>0 && cc<224)
        {
            if(cc<128)
            {
               
               cal(n+8);
            }
            else if(cc>127 && cc<192)
            {
            	cal(n+16);
            }
            else if(cc>191)
            {
            	cal(n+24);
            }
        }
		
	}
 
	static String appendZero(String s)
	{
		String temp="00000000";
		return temp.substring(s.length())+s;
	}
	public static void cal(int n)
	{
		int cnt=0,j=0;
		
		String s[]=new String[4];
		for (int i = 0; i < 4; i++) {
			s[i]="";
		}
		System.out.print("\nSubnet mask is:");
		for (int i = 0; i <32; i++) 
		{
		    if(cnt<8)
		    {
		    	if(i<n)
		    	s[j]+="1";
		    	else
		    	s[j]+="0";
		    	cnt++;
		    }
		    if(cnt==8)
		    {
		    	System.out.print(Integer.parseInt(s[j],2)+".");
		    	cnt=0;j++;
		    }
	
		}
	}
}

/*
Enter IP address:172.12.12.1

 IP in binary is 10101100.00001100.00001100.00000001.

 Enter the number of sub-networks: 4

 Number of bits required for sub-network addressing = 2

Subnet mask is:255.255.192.0.student@student-OptiPlex-390:~$ java Subnet
Enter IP address:110.1.1.1

 IP in binary is 01101110.00000001.00000001.00000001.

 Enter the number of sub-networks: 7

 Number of bits required for sub-network addressing = 3

Subnet mask is:255.224.0.0.student@student-OptiPlex-390:~$ java Subnet
Enter IP address:210.1.1.1

 IP in binary is 11010010.00000001.00000001.00000001.

 Enter the number of sub-networks: 17

 Number of bits required for sub-network addressing = 5

Subnet mask is:255.255.255.248.student@student-OptiPlex-390:~$ 
*/
